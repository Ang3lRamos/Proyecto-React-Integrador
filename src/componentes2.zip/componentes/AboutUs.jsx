import React from 'react';

function AboutUs() {
  return (
    <section className="bg-gray-100 bg-cover bg-center py-16 md:py-24">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              About Us
            </h2>
            <p className="mt-4 text-lg text-gray-500">
            We are a company in charge of managing waste and creating strategies to put it to use, we also provide information on how to recycle correctly.
            </p>
            <div className="mt-8">
              <a
                href="#"
                className="text-base font-medium text-blue-600 hover:text-blue-500"
              >
                Learn more about us &rarr;
              </a>
            </div>
          </div>
          <div className="rounded-lg overflow-hidden shadow-lg">
            <img
              className="w-full h-full object-cover"
              src="https://img.freepik.com/vector-gratis/personas-que-colocan-residuos-reutilizables-contenedor-basura_74855-7781.jpg?w=740&t=st=1680153740~exp=1680154340~hmac=ca7d488528c52a81fe8b238c26a7b597c47eb3d898c1c4ef14be13c93324fa64    "
              alt="Unsplash random photo"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

export default AboutUs;
